#include "Arduino.h"
#include "Nendo.h"
#include "WiFi.h"
#include "ESPAsyncWebServer.h"
#include "AsyncElegantOTA.h"
#include "AsyncTCP.h"
  const char ssid[] = "JROBO_06";
  const char pass[] = "";
  const IPAddress ip(192,168,5,6);
  const IPAddress subnet(255,255,255,0);
  AsyncWebServer server(80);
Nendo::Nendo(int pin)
{    
  pinMode(pin, OUTPUT);
  _pin = pin;
}
void Nendo::setupA(){
    Serial.begin(115200);
    //pinMode(13,OUTPUT);
    WiFi.softAP(ssid,pass);
    delay(100);
    WiFi.softAPConfig(ip,ip,subnet);
    IPAddress myIP = WiFi.softAPIP(); 
    delay(100);  
    server.begin();
    Serial.print("SSID: ");
    Serial.println(ssid);
    Serial.print("AP IP address: ");
    Serial.println(myIP);
    Serial.println("Server start!");
    WiFi.mode(WIFI_AP_STA);
    WiFi.disconnect();
    delay(100);
    
    Serial.print("Wi-Fi Channel: ");
    Serial.println(WiFi.channel());
    server.begin();
    delay(100);
    //WiFi.reconnect();
    server.on("/", HTTP_GET, [](AsyncWebServerRequest *request) {
    request->send(200, "text/plain", "I am JROBO_06 desu");
  });
    AsyncElegantOTA.begin(&server);    // Start ElegantOTA
    server.begin();
    delay(100);
    Serial.println("HTTP server started");
    AsyncElegantOTA.loop();
}

void Nendo::dot()
{
  digitalWrite(_pin, HIGH);
  delay(100);
  digitalWrite(_pin, LOW);
  delay(100);  
}

void Nendo::dash()
{
  digitalWrite(_pin, HIGH);
  delay(2000);
  digitalWrite(_pin, LOW);
  delay(2000);
}
