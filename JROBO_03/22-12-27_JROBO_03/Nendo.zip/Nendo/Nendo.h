#ifndef Nendo_h
#define Nendo_h
#include "Arduino.h"
#include "WiFi.h"
#include "ESPAsyncWebServer.h"
#include "AsyncElegantOTA.h"
#include "AsyncTCP.h"

class Nendo
{
  public:
    Nendo(int pin);
     void setupA();
    void dot();
    void dash();
  private:
    int _pin;
   
};

#endif
